With inSystem as
(	Select [External Document No_]from [urban_NAV600].[dbo].[Urban-Brand GmbH$Sales Header] with (nolock)
	Union
	Select [External Document No_] from [urban_NAV600].[dbo].[Urban-Brand GmbH$Sales Invoice Header] with (nolock)
)
/****** Komplett Storniert ******/
Select esh.[Shop Code], SUM( distinct esh.[Shipping Costs]),COUNT(distinct esh.[External Document No_]), sum (esl.Quantity * esl.[Unit Price Gross Amount])
From [urban_NAV600].[dbo].[Urban-Brand GmbH$eBayNavCSalesHeader] as esh with (nolock)
Left Join inSystem
on esh.[External Document No_] = inSystem.[External Document No_]
Left join [urban_NAV600].[dbo].[Urban-Brand GmbH$eBayNavCSalesLine] as esl with (nolock)
on esh.No_ = esl.[Document No_]
Where inSystem.[External Document No_] IS NULL AND esh.[Order Date] between '2014-02-01' and '2014-02-28'
group by esh.[Shop Code]