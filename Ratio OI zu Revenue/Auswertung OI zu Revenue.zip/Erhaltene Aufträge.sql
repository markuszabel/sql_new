/****** Alle pro Periode erhaltene Auftr�ge ******/
Select ch.[Shop Code], COUNT( ch.ExternalDocumentNo) as OI
From [urban_NAV600].[dbo].[Urban-Brand GmbH$CreateDocumentHeader] as ch with (NOLOCK)
Where  ch.OrderDate between '2014-04-01' and '2014-04-28'
Group by ch.[Shop Code]
order by ch.[Shop Code]